#include <stdio.h>

int main()
{
   printf ("Primer ejemplo\n");
   return 0;
}
